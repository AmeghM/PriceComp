from django import forms
from . models import Cust

class UserForm(forms.ModelForm):
    class Meta:
        model=Cust
        fields=[ 'name',
            'username','email','password'
        ]
        