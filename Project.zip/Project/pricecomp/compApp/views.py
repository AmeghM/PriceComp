from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.template import loader
from . forms import UserForm
from django.urls import reverse
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.views import LoginView
from django.urls import reverse_lazy
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from .models import Cust
from django.contrib.auth.hashers import check_password

# Create your views here.
def home(request):
    return render(request,'index.html')


#user
def sign(request):
    form = UserForm()
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserForm()
    return render(request,'signup.html',{'form':form})

#main
# This uses Django's built-in LoginView
# class CustomLoginView(LoginView):
#     template_name = 'login.html'

#         # Redirect to user dashboard after successful login
#     def get_success_url(self):
#         # You can either use a hardcoded URL or reverse a named URL
#         return reverse_lazy('userdash')


# views.py1
# def login_view(request):
#     if request.method == 'POST':
#         # Get username and password from the POST data
#         username = request.POST['username']
#         password = request.POST['password']
        
#         # Authenticate the user
#         user = authenticate(request, username=username, password=password)
        
#         if user is not None:
#             # If authentication is successful, log the user in
#             login(request, user)
#             return redirect('userdash')  # Redirect to the user dashboard
#         else:
#             # If authentication fails, show an error message
#             messages.error(request, 'Invalid username or password')
    
#     return render(request, 'login.html')

#view2
def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        # Custom authentication for Cust model
        cust = Cust.objects.filter(username=username).first()
        
        if cust and check_password(password, cust.password):  # Password should be hashed
            login(request, cust)  # Log in the user (make sure cust has necessary attributes)
            return redirect('userdash')  # Redirect to the user dashboard page
        else:
            messages.error(request, 'Invalid username or password')
    
    return render(request, 'login.html')

@login_required
def user_dashboard(request):
    return render(request, 'userdash.html')

# def userdash(request):
#      return render(request, 'userdash.html')


#admin
def adminlogin(request):
    if request.method == 'POST':
        # Get username and password from the POST request
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        # Set the predefined username and password
        ADMIN_USERNAME = 'admin'
        ADMIN_PASSWORD = 'password123'
        
        # Check if the credentials are correct
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            return redirect(reverse('admindashboard'))
        else:
            # Show an error message
            messages.error(request, 'Invalid username or password')

    return render(request, 'adminlogin.html')

def admin_dashboard(request):
     return render(request, 'admindash.html')
