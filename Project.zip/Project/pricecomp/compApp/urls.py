from django.urls import path
from . import views
# from .views import CustomLoginView
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('', views.home,name="home"),
    path('sign/', views.sign,name="signUp"),
    # path('login/', views.login,name='userlogin'),
    # path('login/', CustomLoginView.as_view(), name='login'),
    path('adminlog/', views.adminlogin, name='adminlogin'),
    path('admindash/', views.admin_dashboard, name='admindashboard'),
    # path('userdash/', views.userdash, name='userdash'),
     path('login/', views.login_view, name='login'),  # Login page
    path('login/dashboard/', views.user_dashboard, name='userdash'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),  # Logout URL

]